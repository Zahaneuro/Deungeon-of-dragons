import pygame
import sys

pygame.init()
scr = pygame.display.set_mode((1250, 750))
pygame.display.set_caption("Dungeons and Dragons")

icon = pygame.image.load('foto/icon/Avatar.jpg')
pygame.display.set_icon(icon)

menu_music = 'Music/nejnoe-spokoynoe-bezmyatejnoe-raznogolosoe-penie-ptits-v-lesu.mp3'
scene1_music = 'Music/morning-garden-acoustic-chill-15013_[cut_68sec].mp3'

pygame.mixer.music.load(menu_music)
pygame.mixer.music.play(-1)

font = pygame.font.SysFont('arial', 40)
WHITE = (255, 255, 255)

background = pygame.image.load('foto/scene/Menu_bg.jpg')
level1 = pygame.image.load('foto/scene/Tutorial_BG.png')

btn_play = pygame.image.load('foto/batton/image.png').convert_alpha()
btn_exit = pygame.image.load('foto/batton/imageQuti.png').convert_alpha()

def draw_animated_button(image, x, y, scale_hover=1.1, action=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    button_rect = image.get_rect(topleft=(x, y))

    if button_rect.collidepoint(mouse):
        w, h = image.get_size()
        new_size = (int(w * scale_hover), int(h * scale_hover))
        scaled_img = pygame.transform.smoothscale(image, new_size)
        new_rect = scaled_img.get_rect(center=button_rect.center)
        scr.blit(scaled_img, new_rect.topleft)

        if click[0] == 1 and action:
            pygame.time.delay(200)
            action()
    else:
        scr.blit(image, (x, y))

def scene1():
    pygame.mixer.music.stop()
    pygame.mixer.music.load(scene1_music)
    pygame.mixer.music.play(-1)

    running = True
    while running:
        scr.blit(level1, (0, 0))
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
        pygame.display.update()

def main_menu():
    pygame.mixer.music.stop()
    pygame.mixer.music.load(menu_music)
    pygame.mixer.music.play(-1)

    running = True
    while running:
        scr.blit(background, (0, 0))

        draw_animated_button(btn_play, 500, 300, action=scene1)
        draw_animated_button(btn_exit, 500, 430, action=quit_game)

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
        pygame.display.update()

def quit_game():
    pygame.quit()
    sys.exit()

main_menu()